
{xml:lang="cs" ns="https://www.hostovka.cz"}

{id="chutney" short="chutney" author="InternetGuru" ctime="2018-11-26T21:52:04+01:00"}

# Chutney

Chutney, čti čátny, je v mysli mnoha lidí koření, lépe řečeno dochucovací prostředek indické kuchyně ve které se chutney používá nejvíce.

Popularita chutney překročila ale hranice Indie a tudíž se s ním setkáte jako s dochucovacím prostředkem mnoha jiných jídel i jiných kuchyní.

V Indii se chutney dělá denně čerstvé a v mnoha případech ku každému jídlu jiné. Proto jako studenti Hostovky bychom měli vědět, že to co se prodává jako chutnej není všelék na všecko.

Komerčně vyráběné "universální" chutney si musíte napřed vyzkoušet zda se k vašemu jídlu hodí nebo si udělat vaše vlastní.

{id="chutney\_ke\_smazenym_pokrmum"}

## Chutney ke smaženým pokrmům

2 lžíce tence krájených serano chili papriček, 170 g cibule krájené na velké kostky, 1-2 stroužky česneku, 1 ½ šálku čerstvých lístků máty, ½ šálku sekaného cilantro, ¼ šálku limetkové šťávy, 1 lžička praženého cuminu, ½ lžičky sole

Za přidávání trošky vody v mixeru rozšleháme chili papričky, cibuli a česnek na jemnou pastu. Přidáme mátu, cilantro, limetkovou šťávu, cumin a ½ lžičky sole; mixujeme při přidávání několika dalších lžiček vody podle potřeby.

{id="chutney\_s\_mangem\_a\_matou"}

## Chutney s mangem a mátou

Toto chutney se hodí ku většině jídel curry.

  * 1 lžička olivového oleje
  * ¼ šálku drobně sekané cibule
  * 2 lžíce sekaného čerstvého zázvoru
  * 1 drobně sekaná jalapeňo paprička
  * ½ šálku hnědého cukru
  * ½ šálku jablečného octa
  * ¼ šálku rozinek
  * 2 lžičky curry prášku
  * ¼ lžičky mletého hřebíčku
  * 1/8 lžičky skořice
  * 1/8 lžičky mletého muškátového oříšku
  * 1/8 lžičky mletého nového koření
  * 3 ¼ šálku manga krájeného manga
  * ¼ šálku sekaných lístků máty

Na mírném ohni ohřejeme v pánvi olej. Přidáme cibuli, zázvor, a papričku; přikryjeme poklicí a při občasném zamíchání vaříme asi 7 minut. Zvýšíme teplotu, přidáme mango a zvolna vaříme až do vyvaření. Vmícháme mátu.

Nepředpokládám ale že byste si toto chutney chtěli připravovat doma, leda že všechno to koření doma již máte.

Přidal jsem ten recept jen proto, abych ukázal jak nesmyslné všechny ty domácí recepty podobných směsí jsou.

Koření jak víme se prodává v daleko větším množství než v jakém je uvedeno v takových receptech a navíc bych rád viděl jak odměřujete ¼ nebo dokonce 1/8 lžičy nějakého koření, nemluvě o tom, že to koření které doma máte ještě po babičce asi za moc již nestojí.

Tudíž i když mně autoři všech těch krásných kuchařek ve kterých se podobných receptech dočtete vám jako studentům Hostovky musím poradit, abyste si koupili hotové chutney které vám chutná a takovou knížku si vůbec nekupovali.

