
{xml:lang="cs" ns="https://www.hostovka.cz"}

{id="rozmisteni\_buffetovych\_jidel" short="rozmisteni\_buffetovych\_jidel" author="InternetGuru" ctime="2018-11-27T01:33:55+01:00"}

# Psychologie rozmístění buffetových jídel

Bufetové pulty mohou být obdélníkové, postavené podél stěny s jednosměrným vyhrazeným přístupem, nebo volně stojící v prostoru s jednosměrným přístupem po obou stranách, případně kulaté „ostrůvky“ s přístupem se všech stran.

Jídla jsou na těchto pultech rozmístěna v souladu s určitými gastronomickými zásadami, nebo místními zvyklostmi. Jejich počet, množství a jejich druh, se řídí cenou, počtem hostů, jejich společenským postavením, ale hlavně jejich sofistikovaností, o čemž se z nějakého důvodu nikde nemluví.

Při rozmístění jídel na pultech větší důležitost než znalost gastronomie, je znalost psychologiie. Totiž i když se o tom nemluví, tak na jedné straně chceme dát hostům to co chtěj, ale na druhé straně jenom to co jim za jejich peníze patří, nic více-nice méně.

V důsledku toho dáváme na bufety menší talíře, protože host může navštívit ten pult kolikrát chce tak jako tak, ale těmi malými talíři mu to tak trochu zkomplikujeme. Do popředí dáváme tak zvané fillers, neboli hmotné saláty a laciná jídla, kterými si host zaplní svůj talíř tak, že když dojde k těm dražším jídlům, což jsou většinou drahá masa a ryby, hostu moc místa na talíři již nezbývá.

