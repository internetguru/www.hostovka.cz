
{xml:lang="cs" ns="https://www.hostovka.cz"}

{id="kritika\_a\_pochvaly" short="kritika\_a\_pochvaly" author="InternetGuru" ctime="2018-11-27T00:52:13+01:00"}

# Kritika a pochvaly

Jako studenti Hostovky byste měli vědět, že máte morální povinnost poukázat na nedostatky v jídle a servisu protože někdy naši pracovníci, pokud nejsou absolventy některé z těch našich četných hotelových škol, ani nevědí že nějakou chybu dělají.

Hlavním posláním Hostovky je totiž vychovávat hosty a to v naději, že jako sofistikovaní hosté budou působit na některé naše kuchaře aby se zlepšila kvalita jídel a na některé obsluhuící aby se ta obsluha také trochu zlepšila.

Já si stěžuji velice zřídka protože se považuji za odborníka a byl bych pokrytec kdybych nepřiznal že všichni naši kuchaři nebo obsluhující nejsou špatní, stejně tak jako nejsou špatná všechna jídla která naši kuchyři připravují. Proto se snažím být velice tolerantní, a na pochvaly nejsem nijak skoupý a Vy byste měli dělat totéž přestože se mnohdy setkáte s tím že Vám lidé ani nevěří.

{id="umeni\_prijmout\_pochvalu-pripadova_studie"}

## Umění přijmout pochvalu – případová studie

Asi tak v roce 1994 jsem byl v Hradci Královém na obědě v hotelu Černigov, který mimo jiné mi byl velice sympatický. Byl jsem tam s jedním studentem - stopařem, kterého jsem vezl do Prahy, a který mi za to pomohl cestou naložit relativně těžký stůl, za což jsem ho mimo jiné pozval na oběd.

Objednali jsme si každý něco jiného. Obě polévky, které jsme dostali byly velice dobré, a dokonce i horké, a tak jsem zastavil kolemjdoucího pana vrchního, a požádal jsem ho, aby zašel do kuchyně, a vyřídil tam, že ta polévka byla, jak se v Americe říká "Out of this world", neboli vynikající. Pan vrchní se na mně podíval takovým jakoby pohrdlivým pohledem a bez mrknutí oka odešel, ale jak jsem se později dozvěděl, v kuchyni nic neřekl.

Nepamatuji si již, co byla ta hlavní jídla, která jsme dostali po polévce, ale jedno si pamatuji, a sice to, že byla neméně tak dobrá jako ty polévky. Zavolal jsem tudíž našeho "milého" pana vrchního a řekl jsem mu: "Pane vrchní, buďte tak hodný a zajděte ještě jednou do kuchyně a řekněte jim, že nejenom má polévka, ale i toto jídlo je vynikající". Pan vrchní se tentokrát na mě podíval jako kdybych já byl "Out of this world", neboli z Marsu a řekl: "A jinak jsme zdrávi, že ano".

No, a to jsou věci které já kritizuji, protože tragedie českého pohostinství je, že nejenom že někteří lidé neumějí přijmout kritiku, ale ani pochvalu, což by se tady v té Americe, se kterou každému už jdu asi na nervy, nestalo a sice proto, že za minutu potom kdy vám (nevyučený) obsluhující přinese jídlo, se vás přijde zeptat zda je vše v pořádku.

Američané si v České republice možná nestěžují z obavy, aby je za to někdo nezmlátil jako v tom případě taxikářů, kteří v tom lepším případě dají zákazníkovi, který si stěžuje elektrický šok, ale doma si stěžují, ale ne často.

Doma (v Americe) si totiž postěžují jednou nebo dvakrát a potřetí jdou někam jinam. Když se to tak vezme, tak jsou to právě stížnosti, které přispěly té vysoké úrovni služeb v americkém pohostinství.

Američtí restauratéři se totiž naučili stížnostem předcházet tím, že se snaží hostům dát nejenom to co chtějí, ale také co jim patří. What a country!

Problém v Česku byl zatím v tom, že málokterý host věděl co mu patří, ale nyní díky Hostovce se situace doufám změní a hosté si na ty nedostatky budou bez ostychu stěžovat.

