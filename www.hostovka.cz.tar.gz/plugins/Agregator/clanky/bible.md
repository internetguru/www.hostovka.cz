
{xml:lang="cs" ns="https://www.hostovka.cz" class="docinfo linklist" data-source="http://2017.hostovka.cz/clanek.php?clanek=102.html" data-og-image="files/preview/clanky/bible/general.jpg" data-og-type="article"}

{id="bible" ctime="2005-11-06" author="Michael Klíma" short="Bible" authorid="hostovka/michael_klima"}

# Bible

{kw="jídla a jídelní lístky"}

K tomu abyste se stali sofistikovanými hosty vám studium Hostovky stačit nebude.K tomu abyste se stali znalci jídel se sice nemusíte učit vařit, nicméně byste měli do některých dobrých kuchařek nahlédnout. To ale jsem učil i mé studenty na jedné hotelové škole v Americe kde jsem 15 let učil.

Moji studenti se mně ale při tom často ptali které knihy jsou dobré a které by měli číst. Při tom jsem jim tudíž dával otázku která kniha podle nich je nejpublikovanější a nejčtenější. Zajímavé je, že většina se shodovala v tom, že je to bible, a údajně proto, že ta byla přeložena téměř do všech světových jazyků.

V tom, jestli bible je také nejčtenější se již všichni neshodovali, přesto, že někteří, jak říkali, měli doma bible i dvě, ale do žádné z nich se ještě nikdy nepodívali.

Když jsem se ale zeptal, kolik mají doma kuchařek, tak většina se shodovala v tom že jich doma mají tolik, že ani neví kolik, a to nemluvili o těch odborných učebnicích vaření které si díky studiu na hotelové škole už také zakoupili. Že by ty kuchařky četli tak jako někteří lidé čtou bibli, to se nedá říci, nicméně někteří přiznali, že si v těch kuchařkách někdy listují i před spaním což si myslím, že u těch studentů byl jen BS protože to říkali jen aby mi udělali radost.

Jedno americké pořekadlo říká: "A picture is worth thousand words", neboli že obrázek poví více než tisíc slov, a to si nakonec uvědomili i vydavatelé biblí pro děti, které jsou dnes doplněny líbivými barevnými obrázky. Na toto se ale spoléhají i vydavatelé dnešních kuchařek, a dá se říci že kuchařská kniha bez líbivých barevných obrázků dnes nemá téměř žádnu šanci.

Mnohý zkušený nebo profesionální kuchař k přípravě jídla nic jiného než jeho barevný obrázek ani nepotřebuje, ale jak víme barevné obrázky jsou stále ještě nákladné a tak podle názvu si ty recepty budeme volit ještě hodně dlouho.

Problém ale je v tom, že recepty a kuchařské knihy dnes píše kde kdo a přitom málokterý z těch autorů ví, že jsou jakési nepsané zákony které začínají již tím názvem receptu aby eventuálně kažkdý měl možnost ověit jeho autentičnost, případně původ.

Moji studenti mi říkali že podle obrázku nebo lákavého názvu jídla si mnohdy vyberou recept, který by si eventuálně chtěli vyzkoušet, ale ve většině případů to vzdali již při čtení názvu nebo při čtení údajů o množství a druhu surovin kter0 budou potřebovat a hlavně při čtení nedostatečně, nebo naopak příliš zdlouhavě popisované přípravě.

Během mé šedesátileté mezinárodní praxe jsem se zatím nikde ve světě nesetkal informacemi nebo s návodem jak psát recepty, jak zvolit ten správný formát a styl, jaké dát těm receptům odpovídající jméno apod.

Největší chucpa je, že většina těch autorů to opisuje jeden od druhého (co si také mají stále vymýšlet), a někteří se snaží vynalézt kolo tím, že nějakému starému receptu dají nové jméno a eventuálně se prohlásí za jeho autora a struktura receptu zůstává stejná, ale Who cares!

Proto se budete muset připravit na to, že ne všechny knihy které jsou u nás dnes na trhu jsou dobré, ale studiem Hostovky se časem naučíte ty dobré rozeznávat.

