
{xml:lang="cs" ns="https://www.hostovka.cz" class="docinfo linklist" data-source="http://2017.hostovka.cz/clanek.php?clanek=121.html" data-og-image="files/preview/clanky/sacher_eduard/preview.jpg" data-og-type="article"}

{id="sacher\_eduard" ctime="2005-11-29" author="Michael Klíma" authorid="hostovka/michael\_klima"}

# Sacher Eduard

{kw="ubytování"}

Kostel svatého Štěpána ve Vídní je jen několik kroků od hotelu Sacher, ale nejsem si jist co je u vídeňských turistů populárnější, jestli ten nádherný oltář kostela nebo dort kterým se zakladatel hotelu Sacher proslavil.

Na přelomu století Franz Sacher, bývalý vrchní cukrář na dvoře Metternicha, vytvořil tuto čokoládovou ambrozií kerá mu přinesla popularitu po celém světě.

Jsou to tři vrstvy čokoládového piškotového korpusu které jsou silně potřeny meruňkovou marmeládou a slepeny do dortu který je pokryt polevou z hořké čokolády. Podává se v silných trojúhelníkových řezech pokrytých čerstvou šlehačkou které se v Rakousku říká Obers.

{id="lacine_ubytovani"}

## Laciné ubytování

"Už jsi slyšel o tom hotelu Sachr ve Vídni?" se mně jednou zeptal můj dobrý přítel v Americe. "V tom hotelu", pokračoval můj přítel, "jdeš odpoledne do kavárny na pravou vídeňskou kávu s pravou Obers", což ve Vídni znamená šlehačka," dají ti k tomu pravý Sachrův dort, také s tím Obers, a nic tě to nestojí."

"Večer jdeš do jejich překrásné restaurace, kde ochutnáš pravou vídeňskou kuchyni, a také tě to nic nestojí. Po večeří jdeš do jejich Weinstuberl, kde ochutnáš typická rakouská vína, a poslechneš si typický vídeňský šraml, a celá tato Gemûtlichkheit tě zase nic nestojí."

"Nakonec se vyspíš v překrásné Biedermeirové posteli s hedvábným povlečením, a to nejenom že tě také nic nestojí, ale navíc když se ráno probudíš, tak najdeš dvě stodolarové bankovky pod polštářem."

"To není možné, ty jsi tam byl?", jsem se zeptal. "Já ne", povídá můj přítel, "ale moje paní tam byla".

