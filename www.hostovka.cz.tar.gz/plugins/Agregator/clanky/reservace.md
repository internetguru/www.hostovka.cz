
{xml:lang="cs" ns="https://www.hostovka.cz" class="docinfo linklist" data-source="http://2017.hostovka.cz/clanek.php?clanek=139.html" data-og-image="/files/preview/clanky/reservace/general.jpg" data-og-type="article"}

{id="reservace" ctime="2006-03-13" author="Michael Klíma" short="Reservace" authorid="hostovka/michael_klima"}

# Reservace

{kw="restaurace a servis"}

Jako sofistikovaní hosté nebo jako studenti Hostovky byste také měli vědět, jak, kdy a proč si dělat v restauracích reservaci.

Abych vám ale řekl pravdu, tak pokud je něco co jsem na pražském porevolučním pohostinství neměl vůbec rád, tak TO byly právě reservace.

Kolikrát jsem přišel do restaurace sám, hned po otevření, kdy ta restaurace byla ještě úplně prázdná, ale první co se mně zeptali bylo, zda mám reservaci.

Byla to taková uvítací fráze většiny pražských restaurací, ve kterých si ti zaměstnanci mysleli že je to nóbl a že tím pádem si přidávají další hvězdičku k těm čtyřem které si již na dveře dali.

Věřte mi, že kolikrát, místo toho abych se od pana maître d' nechal "drezírovat" jsem se otočil a šel jinam. Jenomže tím jsem kolikrát potrestal jen sám sebe, protože v jiných restauracích nebylo lepší. To bylo v době kdy většina restaurací žila ze "skupin", teď ale přišla bída na kozáky. Skupiny již tolik nejezdí a tak dnes i skupina dvou lidí je jim dobrá. Já vím, že v každé dobré restauraci, a to nejenom v Česku, obzvláště když přijdete ve špičce, musíte na váš stůl počkat, což pokud to není déle než 15-20 minut mi tak moc nevadí obzvláště když tam mají barový pult u kterého si mohu dát můj drink.

Nicméně jsem přišel na to, že se člověk musí umět přizpůsobit trendu a proto, obzvláště když mám společnost, si reservaci udělám předem.

Reservování míst v restauracích má ale své techniky. Dnes pokud si děláte reservaci telefonicky, tak pro tu restauraci není problém zjistit kdo jste, lépe řečeno ze kterého telefonu jste si tu reservaci udělal, ale i tak já udávám smyšlené jméno.

Křestní jméno ale někdy nestačí protože když například řeknete že se jmenujete Karel, tak se vám může stát že nějaký Karel tam již reservaci má a proto je dobře tředa říci že jste Karel čtvrtý. Oni vám to sice nevěří ale zní to dobře. Když ale například děláte reservaci na jméno Jiří, tak říci, že jste ze Žižkova dnes už nezní tak jako když řeknete, že jste Jiří z Poděbrad. Někteří lidé ku svému jménu přidají i svůj titul, a mají rádi, když ho potom hosteska tím titulem hlasitě přivítá, ale samotnému personálu to moc neříká. Titul profesor stále ještě vůbec neletí, což je ještě z dob, kdy profesoři brali o mnoho méně než samotní číšníci, kteří tím pádem věděli že od nějakého pana profesora žádný velký tuzér čekat nemohou. Doktor také není moc dobré protože o doktorech se říká, že jsou to největší škrobové a titulem inženýr také již nikoho moc nenadchne protože takový titul dnes má již kde kdo, a navíc vám to stejně nevěří, no a o titulu magirst, bych se vůbec ani nezmiňoal protože toho si nikdo už vůbec neváží. Dnes tak nejvýše letí kongresman, starosta, případně primátor, nebo hejtman což je více, ale já osobně věřím na jména i když třeba smýšlená.

Se jmény musíte ale být opatrní. V Americe například když si objednáte stůl na jméno Clinton, tak vás v té restauraci při příchodu čeká hned nějaká Monika. Na druhé straně když udáte jméno Bush, tak musíte přidat jestli jste junior nebo senior, protože každý z nich má jinou popularitu která se navíc mění někdy minutu od minuty. Jména politiků také moc dobrá nejsou, ledaže je to někdo kdo je pevně v sedle. Proto nejlepší je udávat jméno někoho kdo je stále populární jako je například Karel Gott, ale pak se vystavujete nebezpečí že u dveří bude čekat řada Gottových ctitelů na autogram.

Reservací to ale teprve začíná a tak vám postupně popíši na co si pak po příchodu jako studenti Hostovky musíte dávat pozor.

V restauraci při reservaci se vás někdy zeptají na vaše telefonní číslo což ale je úplně na nic, protože když náhodou nepřijdete, tak vám stejně volat nebudou, protože sami vědí že to číslo může b‎ýt také smyšlené.

Zpravidla se ale zeptají na dobu na kterou si chcete reservaci udělat a kolik lidí bude ve vaši skupině. Některé restaruace mají tak zvané dvoje sezení, neboli že reservují stoly dejme tomu od 18:00 do 20:00 a potom od 18:00 do závěrečné hodiny a na to by vás měli upozornit.

Na toto sice nemají zákonné právo, ale je to jakási slušnost to respektovat. Nemějte ale obavy, pokud si objednáte stůl na 18:00 hodinu a zdržíte se déle než do 20:00 tak na vás policii nezavolají nicméně jim někdy zkomplikujete život jestliže mají dalších několik hostů kteří na stůl čekají. V takovém případě, pokud je to v nějaké kultivované zemi se ta restaurace snaží tu situaci nějak vyřešit aby uspokojili jak vás tak i ty čekajicí hosty.

Nicméně jako studenty Hostovky vám musím upozornit na to, že v Česku, které se považuje za kultivovanou zem, se vám může stát něco přímo otřesného což si můžete přečíst na stránkách http://labuznik.com/main.php v oddělení Diskusní forum v kolonce KDE SE DOBŘE DAŘÍ, pod titulkem: Šokující zážitek ze Slaného - JIŽ NIKDY VÍCE COUNTRY CLUB!!!!!

Já jsem do toho Labužníka přidal moji reakci a nechci aby se z Hostovky stala nějaká stěžovatelna, ale abych skutečně dělal to co káži jsem cítil za povinnost vás jako studenty hostovky s tímto případem seznámit...

{id="raison\_daitre\_hostovky"}

## Raison dâitre Hostovky

Dnes většina čtenářů těchto stránek ví že se považuji za odborníka v pohostisntví a cestovním ruchu, ale málo lidí ví, že člověk je největším nepřítelem té třídy ze které vzešel tudíž i já, protože jem vzešel z pohostisntví, jsem jeho největším nepřítelem.

Toto je ale jen takové mé povídání, protože stále ještě se snažím tomu českému pohostinství pomoci, nicméně je pravdou že jsem nepřítelem všech těch kteří to pohostisnství przní podobným způsobem jako v tom Cuntry Klubu ve Slaném.

Já přesto, že v Česku trvale nežiji tak si myslím že jsem těch česk‎ý‎‎ch restaurací navštívil jako málo kdo a proto vím, že je dnes v Česku celá řada dobr‎ých restaurací a zaměsnanců kteří dělají svoji práci ku spokojenosti jejich hostů, ale mohu také říci, že i když ne tak otřesn‎ým způsobem, tak ale i jinými způsoby tomu pohostisntví škodí i jiní.

V daném případě, jak píše autorka, se jednalo o gastroprofíky, pedagogy v pohostinství kteří tento otřesný případ eventuálně použijí při v‎ýchově, ale tragedie je že veká většina návštěvníků restauračních podniků nejsou sofistikovaní hosté a ti si prostě podobné jednání nechají líbit protože si myslí, že to tak má b‎ýt.

Proto vlastně jsem založil Hostoku, neboli jakousi univerzitu pro hosty, která mimo jiné je první škola toho druhu na světě, ve které by se měli studenti naučit b‎ýt kvalfikovanými kritiky poskytovaných restauračních a hotelov‎ých služeb a toho co jim za jejich peníze patří.

Po přečtení tohoto případu ale vidím že ta Hostovka je něco čemu se říká: ?Too little and too late?, neboli, že je to málo, stejně tak jako je málo, že tento přpad byl popsán jen na těchto stránkách.

Proto si myslím, že by podobné případy měly b‎‎ýt pratnýřovány nějakým efektnějším způsobem než nabádáním k tomu aby do toho Kanráče nikdo nechodi.

Se špatnou zkušeností s pohostistinstvím měl i president AKC ČR pan Miroslav Kubec kter‎ý‎ také říká, že před tím podnikem ve kterém tu špatnou zkušenost měl bude každého varovat.

Já jsem kdysi sepsal několik bodů o tom co hosté nemají rái a tak teď, až mi opadne ten fofr, musím ještě sepsat vše na co by si hosté měli stěžovat, ale někdo by mi musel poradit kde to pak uveřejnit aby to oslovilo širok‎ý okruh návštěnvíků restaurací.

P.S. Jsem rád, že jsem se dozvěděl co to je ten kantráč.

