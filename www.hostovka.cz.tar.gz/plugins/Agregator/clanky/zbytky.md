
{xml:lang="cs" ns="https://www.hostovka.cz" class="docinfo linklist" data-source="http://2017.hostovka.cz/clanek.php?clanek=117.html" data-og-image="files/preview/clanky/zbytky/preview.jpg" data-og-type="article"}

{id="zbytky" ctime="2005-11-26" author="Michael Klíma" authorid="hostovka/michael_klima"}

# Zbytky

{kw="jídla a jídelní lístky"}

Zbytky, někdy zvané resty, jsou největším bolehlavem každého manažera kuchyně. Zbytky jsou nenahraditelné ztráty. Zbytky mohou být neprodané porce prvotřídních a drahých jídel, které se z nějakého důvodu neprodaly a které tím pádem ztrácí až 50% své hodnoty ovšem v praxi to neznamená, že by na těch zbytcích bylo něco špatného nebo že jsou zdravotně nebezpečné.

Pokud se nezávadnosti zbytků týká tak záleží jak se s těmi zbytky zachází. Proto jako studenti Hostovky bychom nad některými zbytky neměli ohrnovat nos, ba naopak protože někdy takový "zbytek" je vlastně velkou lahůdkou.

Zbytky totiž nejsou jen neprodané porce vařených jídel. Surové potraviny které nebyly zpracovány a prodány v plánované době jsou ve skutečnosti také "zbytky".

Jsou ale i "zbytky" které se tvoří úmyslně. Já například když jsem měl na lístku smažený lilek, jsem ho vždy usmažil více než jsem předpokládal že se ho prodá a druhý den jsem ten zbytek lilku prodal jako specialitu zvanou Lilek po Milánsku.

{id="lilek\_po\_milansku"}

## Lilek po milánsku

Plátky obalovaného, smaženého lilku (zbytek z minulého dne), rajská omáčka, na tenké plátky krájený nebo strouhaný sýr, bešamelová omáčka, přepuštěné máslo.

Dno máslem vymaštěného pekáčku pokryjeme plátky smaženého lilku, pokryjeme tenkou vrstvou sýra a přelijeme bešamelovou omáčkou. Tímto způsobem přidáme ještě 2 nebo tři vrstvy smaženého lilku a ostatních surovin tak abychom zakončili bešamelovou omáčkou. Povrch posypeme strouhaným sýrem, pokapeme rozpuštěným máslem a pečeme v troubě dozlatova.

Pečený lilek nakrájíme na porce požadované velikosti a podáváme jako hlavní chod s opečenými bramborami nebo s bramborovou kaší.

