
{xml:lang="cs" ns="https://www.hostovka.cz" class="docinfo linklist" data-source="http://2017.hostovka.cz/clanek.php?clanek=111.html" data-og-image="files/preview/clanky/allspice/general.jpg" data-og-type="article"}

{id="allspice" ctime="2005-11-18" author="Michael Klíma" short="Allspice" authorid="hostovka/michael_klima"}

# Allspice

{kw="kdo-kdy-kde"}

Allspice (angl.) latinsky Pimenta dioica, španělsky Pimenta gorda, francouzsky piment, německy piment, švédsky kryddpeppar, italskypeppe di giamaica portugalsky pimenta-da- Jamaica, russian умаусkи перец, arabsky Bahar, anglicky takéJamaica pepper nebo pimento, česky nové koření.

K novému koření, lépe řečeno k jeho anglickému jménu se váže jedna zábavná příhoda...

U Marriottu v Chicágu na letišti, kde jsme připravovali tisíce jídel pro různé mezinárodní letecké společnosti, pro mě pracovali většinou Mexičané kteří nebyli sice vyučení kuchaři, ale měli již několik let praxe a někteří mluvili docela obstojně anglicky.

Tudíž když se pro nějakou zahraniční společnost mělo připravit nějaké zcela neznámé jídlo, tak jsem těm kuchařům dal v angličtině podrobný recept s přesným popisem jeho přípravy, vysvětlil jsem jim jak to jídlo udělat a musím říci, že většinou to bez problémů zvládli.

Jednoho dne jsem přišel k Jessusovi, což byl kuchař který připravoval jídla pro první třídy, s novým receptem. Vysvětlil jsem mu jak to udělat, prošli jsme, zda má všechny potřebné suroviny a koření, a po jeho ubezpečení, že je mu vše jasné, jsem šel na obchůzku ostatních oddělení.

Asi po deseti minutách jsem se vrátil k Jessusovi, který měl na svém pracovním stole vyložené všechno koření které jsme v té kuchyni měli v takovém vysokém pojízdném kabinetu.

Bylo jich asi 40 a já nevěděl to znamená. Vypadalo to jako když Jessus chce tu skřínku vyčistit a tak jsem se ho zeptal co to vlastně dělá. Jessus mi řekl abych neměl starosti, že přeci umí číst, a že mám v tom receptu jasně napsáno že se k jeho přípravě má použít allspice.

Nu, ukázalo se, že Jessusova angličtina přeci jenom nebyla ještě tak dobrá, protože by jinak věděl, že allspice, psáno dohromady je nové koření a že všechno koření by se muselo napsat zvlášť "all spice".

