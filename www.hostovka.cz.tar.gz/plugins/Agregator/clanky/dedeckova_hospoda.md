
{xml:lang="cs" ns="https://www.hostovka.cz" class="docinfo linklist" data-source="http://2017.hostovka.cz/clanek.php?clanek=133.html" data-og-image="files/preview/clanky/dedeckova_hospoda/general.jpg" data-og-type="article"}

{id="dedeckova\_hospoda" ctime="2006-02-01" author="Michael Klíma" short="Dědečkova hospoda" authorid="hostovka/michael\_klima"}

# Dědečkova hospoda

{kw="případová studie"}

Můj dědeček, který měl za prvé republiky hospodu na vesnici, nevěděl nic o marketingu a o kalkulaci cen. Ceny dělal takové, aby jeho hosté si je mohli dovolit, a snažil se jim dát co jim patřilo. Dědeček neměl sice hotelovku, ale měl zdravý selský rozum a tak si myslím, že tu hospodu vedl dobře.

Dědeček neměl ani účetního a celkové jeho účetnictví spočívalo v tom, že po nedělní muzice, po zaplacení pivovaru za pivo, řezníkovi za maso a pekaři za chleba, (zeleninu měl z vlastní zahrádky), se podíval do štrajtofle, a když tam něco zbylo, tak řekl: "Tak nám zaplať P.B. mámo zbylo to co nám patří."

Dnes ale tajemství dobrého hospodaření a dosažení maximálních zisků je vyjadřováno jako Food Cost, zkráceně FC, neboli procentem nákladů na potraviny. No, a to je něco s čím se jako studenti Hostovky dříve nebo později setkáte, ale věřte mi že vám jako hostům ten dobrý či špatný FC vůbec nic neřekne.

Podle mé teorie je to ale hlavně obrat který svědčí o tom, že ta restaurace dělá něco dobře, neboli že dává hostům to co jim patří a proto tam lidé chodí.

Nicméně musím dodat, že to není ještě zárukou toho že ta restaurace je profitabilní. Možná že mají špatně vykalkulované ceny a že každým hostem který tam vkročí peníze spíše prodělávají, neboli ne FC ale to co zbude ve šrajtofli je rozhodující.

