
{xml:lang="cs" ns="https://www.hostovka.cz" class="docinfo linklist" data-source="http://2017.hostovka.cz/clanek.php?clanek=159.html" data-og-image="/files/preview/clanky/liquid_smoke/general.jpg" data-og-type="article"}

{id="liquid\_smoke" ctime="2006-07-09" author="Michael Klíma" short="Liquid smoke" authorid="hostovka/michael\_klima"}

# Liquid smoke

{kw="co-kdy-kde"}

Na stránkách www.gastronews.cz se mně někdo zeptal co to je "liquid smoke". Nikdy by mě nenapadlo, že se na něco takového někdy někdo zeptá.

Liquid smoke je tekutý kouř, což je americký vynález tak jako například česnek bez zápachu a zápach bez česneku a jiné podobné umělé příchutě jejichž používání by v gastronomii mělo být trestné.

Stejně trestné by mělo být když někdo se o liquid smoke zmíní nebo ho dokonce použije ve svém receptu a přitom se nezmíní co to vlastně je.

Na stránkách www.gastronews.se jeden čtenář ohradil proti tomu, že používám anglické gastronomické výrazy což bych chtěl u této příležitosti upřesnit.

Ano, já používám anglické gastronomické výrazy a sice proto, že angličtina se v gastronomii používá čím dále tím častěji a dokonce častěji než francouzština. Pokud se ale týká mně, tak se můžete přesvědčit o tom, že používám i výrazy německé, francouzské, italské a dokonce i ruské a že jen málokdy opomenu napsat ekvivalent takového výrazu v češtině a ty ruské dokonce většinou napíši azbukou.

Liquid smoke je ale úplně jiné zvíře. Něco takového bych v mých receptech nikdy nepoužil. Liquid smoke se v Americe používá do tak zvaných "rádoby uzenin", neboli do masných výrobků které se neudí a dá se jim jen uzená vůně a chuť.

Ale budiž, to je při průmyslové výrobě, ale 99% lidí při domácí nebo restaurační přípravě jídel ten tekutý kouř neumí používat a takové výroby jsou pak spíše odporné než přitažlivé.

