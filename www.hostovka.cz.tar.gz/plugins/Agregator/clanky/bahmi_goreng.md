
{xml:lang="cs" ns="https://www.hostovka.cz" class="docinfo linklist" data-source="http://2017.hostovka.cz/clanek.php?clanek=113.html" data-og-image="files/preview/clanky/bahmi_goreng/preview.jpg" data-og-type="article"}

{id="bahmi\_goreng" ctime="2005-11-21" author="Michael Klíma" authorid="hostovka/michael\_klima"}

# Bahmi Goreng

{kw="jídla a jídelní lístky"}

Češi dnes podstaně více cestují ale v zahraničí často přichází o požitek z jídel které si neobjednají protože je neznají. Naštěstí ale teď máme Hostovku na které se o několika populárních jídel dozvíme více ještě než do zahraničí vyrazíme.

Jedním takovým jídlem je Bahmi goreng se kterým se setkáte po celém světě. Je to jídlo z těstovin, vepřového masa původem z Indonésie, ale dá se říci, že ho po celém světě zpopularizovali Holanďané, kteří si toto vynikající jídlo tak říkajíc přivlastnili. Popularitě tohoto jídla přispěla jednoduchost jeho přípravy.

K přípravě této speciality uvaříme ve slané vodě nudle, které po scezení dáme v míse do chladničky. Do jiné mísy dáme na nudličky nakrájené libové maso, zalijeme ho sójovou omáčkou, přidáme drcený česnek a na kousky krájenou cibuli zelnačku; vše dobře promícháme a uložíme také v chladničce.

Poté uděláme tenkou vaječnou omeletu, kterou nakrájím na tenké nudličky (julienne) a přidáme k masu. Po několikahodinovém marinování osmahneme maso na trošce horkého oleje v pánvi, (nejlépe ve woku) a dáme stranou.

Dříve než pánev má možnost vychladnout, přidáme do ní několik kapek oleje, nahrubo nakrájenou cibuli a strouhaný čerstvý zázvor. Vše rychle osmahneme a dáme taktéž stranou. Do horké pánve dáme naběračku vývaru, na tenké plátky krájené bambusové výhonky a na hrubé julienne nakrájené čínské zelí bok choy. Zeleninu krátce oblanšírujeme, přidáme hrst loupaných krevetek, krátce prohodíme a přidáme marinované maso s cibulí, a osmahnutý zázvor. Zalijeme trochou sójové omáčky se lžičkou máčeného škrobu rozředěné vývarem. Vše velmi krátce podusíme, okraje pánve zakápneme sezamovým olejem a směs dáme stranou.

Vařené nudle dobře ocedíme a opražíme dochřupava v horkém oleji. Usmažené nudle přimícháme k masové směsi nebo je dáme na horkou mísu a masovou směs na ně nalijeme. V Indonésii bahmi goreng zdobí natvrdo vařeným vejcem osmahnutým v horkém tuku a krájeným na čtvrtky.

