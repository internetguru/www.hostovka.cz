
{xml:lang="cs" ns="https://www.hostovka.cz" class="docinfo linklist" data-source="http://2017.hostovka.cz/clanek.php?clanek=43.html" data-og-image="files/preview/clanky/alois_krofta/general.jpg" data-og-type="article"}

{id="alois\_krofta" ctime="2005-07-20" author="Michael Klíma" short="Alois Krofta" authorid="hostovka/michael\_klima"}

# Alois Krofta

{kw="kdo-kdy-kde"}

Když pražský architekt Alois Krofta ve třicátých letech otevíral hotel Alcron (zkratka jeho jména), tak si jako šéfkuchaře s mezinárodní zkušeností přivezl Floriána Zimmermanna až z Nového Yorku.

Zimermann byl Čech, s několikaletou praxí ve Francii a v Americe a kdo si ho pamatujete tak víte, že nebyl žádná primadona. Zimmermann byl gentleman a podle mně měl daleko více zkušenosti s mezinárodní kuchyní než kterýkoliv z francouzských kuchařů kteří své umění ale uměli prodat lépe než on.

Od tehdejších kuchařů v ČSR se Zimmermann lišil tím, že nikdy nezvýšil hlas a který učedníky oslovoval "pane".

Architekt Krofta nejenom že dbal na personál, ale dbal i na vybavení hotelu, které na tu dobu nemělo chybu. Rovněž tak i kuchyně byla ukázkou jeho vysoké odbornosti.

