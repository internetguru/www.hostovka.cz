
{xml:lang="cs" ns="https://www.hostovka.cz" class="docinfo linklist" data-source="http://2017.hostovka.cz/clanek.php?clanek=158.html" data-og-image="/files/preview/clanky/spravne_spatne/general.jpg" data-og-type="article"}

{id="spravne\_spatne" ctime="2006-07-08" author="Michael Klíma" short="Co je správné a co ne" authorid="hostovka/michael\_klima"}

# Co je správné a co ne

{kw="etika"}

Kolem roku 1958, Hotelový a cateringový institut Velké Británie se rozhodl stanovit jednou provždy zásady toho co je správné a co ne v gastronomickém světě. Dvanáct vysoce kvalifikovaných kuchařů bylo jmenováno do komise která měla vypracovat jakýsi Kuchařský Kodex.

Po dvou a půl letech týdenních schůzek, nekonečných diskusí a kontraverzí tento zřejmě dobrý záměr upadl do zapomenutí.

Tito kuchaři kteří zastupovali celou řadu etnických kuchyní se nemohli shodnout na nějakých jednotných zásadách , protože co je dobré a co ne z velké míry záleží na dobrozdání dané sociální skupiny v daném čase. To co je pro jednoho lahůdkou může být pro druhého něčím odporným. Jmenujte kterékoliv jídlo jisté skupiny lidí a zcela určitě najdete jinde ve světě jinou skupinou která by toto jídlo vůbec ani nepozřela.

Skutečnost že francouzští kuchaři při zahušťování šťáv dávají přednost bramborovému škrobu před rýžovým má opodstatnění jedině v tom, že bramborový škrob ve Francii je lacinější a od nepaměti snadněji k dostání než škrob rýžový který naopak je ze stejných důvodů oblíben u čínských kuchařů.

