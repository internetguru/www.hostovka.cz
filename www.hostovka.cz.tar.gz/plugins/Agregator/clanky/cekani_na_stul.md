
{xml:lang="cs" ns="https://www.hostovka.cz" class="docinfo linklist" data-source="http://2017.hostovka.cz/clanek.php?clanek=140.html" data-og-image="/files/preview/clanky/cekani\_na\_stul/general.jpg" data-og-type="article"}

{id="cekani\_na\_stul" ctime="2006-03-13" author="Michael Klíma" short="Čekání na stůl" authorid="hostovka/michael_klima"}

# Čekání na stůl

{kw="restaurace a servis"}

Reservace stolů není ve všech restauracích běžná. Restaurace ve kterých je reservace nutná obsazují stoly většinou dvakrát za večer čemuž se říká double sitting a proto se musíte rozhodnout na kdy si váš stůl reservovat.

Je takový nepsaný zákon, že pokud jste si udělali reservace na prvé sezení, dejme tomu od 18:00 do 20:00, že musíte ve 20:00 váš stůl opustit.

Tudíž pokud máte v úmyslu sedět po jídle u stolu ještě déle, tak je rozumnější si udělat reservaci na pozdější dobu, protože v tom případě můžete u vašeho stolu sedět až do uzavírací hodiny.

I při dobré organizaci se ale stane, že stůl reservovaný na určitou dobu není při vašem příchodu ještě volný. V takovém případě restaurace se snaží hostu čas čekání na stůl nějakým způsobem zpříjemnit a z toho důvodu vám nabídnou místo u baru, pokud ho mají, nebo mají jakési předsálí, neboli čekárnu které se někdy říká lounge, ve které vám čekání zpříjemní tím, že vám zde podají váš oblibený koktejl nebo jiné občerstvení které připíší na váš účet.

V některých restauracích, pokud čekání na reservovaný stůl je neúměrně dlouhé vám ten drink dají "complimentary" neboli "on the house", česky "na dům", ale moc se na to nespolehnete.

Jako studenti Hostovky nebo jako sofistikovaní hosté byste ale měli vědět, že když se váš stůl uvolní, by vám některý z obsluhujících měl vaše nedopité drinky přenést k vašemu stolu protože to abyste si ty drinky ku stolu nesli sami nepatří zrovna k tomu nejlepšímu bontonu.

Dnes mimo několka málo restaurcích si málo která restaurace může dovolit mít tak zvaný Štamtish, neboli stůl pro pro stálé hosty a naopak je běžné přisazování ku stolu. Viz Opice tu nemáme.

