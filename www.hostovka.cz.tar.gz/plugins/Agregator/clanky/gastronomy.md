
{xml:lang="cs" ns="https://www.hostovka.cz" class="docinfo linklist" data-source="http://2017.hostovka.cz/clanek.php?clanek=197.html" data-og-image="/files/preview/clanky/gastronomy/general.jpg" data-og-type="article"}

{id="gastronomy" ctime="2006-12-09" author="Michael Klíma" short="Gastronomy" authorid="hostovka/michael_klima"}

# Gastronomy

{kw="jídla a jídelní lístky"}

GASTRONOMY je označení americké gastronomie, která se podstatně liší od všech těch známých světových gastronomií.

Já jsem přímo šokován kam všude dnes, po těch 40 letech toho gastronomického temna Češi již jezdí a věřte mi, že já jsem ten poslední kdo by jim to záviděl.

Někdo by mně musel přesvědčit o opaku, ale já se obávám, že v mnoha případech při svých zahraničních cestách nevědí co jíst, co pít a co jim za jejich peníze patří protože není nikdo kdo by jim to řekl.

Pokud se gastronomie týká tak každá jejich zahraniční cesta je jen polovičním zážitkem pokud o gastronomi jejich cílové země nic nevědí a proto jsem se rozhodl podělit se se studenty Hostovky o to co o některých cizích gastronomií vím.

Zabývám se studiem etnických kuchyní od nepaměti, ale zvládnout podrobně všechny etnické kuchyně je nemožný úkol, a také proč by se tím člověk měl zabývat.

Zaměřil jsem se proto jen na některé, které si z nějakého důvodu zasloužily moji pozornost. Je jich asi 136, ale ani o těchto nemohu říci, že bych je zvládl do důsledku.

Procestoval jsem téměř celý svět ale téměř 40 let žiji v Americe a stále jsem mezi lidmi, a tak si myslím, že bych měl hovořit napřed hlavně o Američanech a o jejich gastronomi která nakonec v některých směrech je mnoha jiným zemím modelem.

Neznamená to ale, že vám chci podat návod jak s Američany zacházet, protože právě u Američanů, na to není šablona.

Nechci se zde zmiňovat o těch pravých Američanech tj. o Severo-amerických Indiánech, těch do Česka nebo na Slovensko pravděpodobně moc nezavítá, a vy se s nimi při cestách do Ameriky mimo těch indiánských reservací nejspíše také nesetkáte, chtěl bych se ale zmínit o těch ostatních Američanech, přivandrovalcích z celého světa, včetně těch v Americe již narozených.

Všichni, jak ta první druhá nebo i třetí generace přistěhovalců mají v sobě něco ze svých předků a je zajímavé, že se to nejvíce projevuje ve stravovacích zvyklostech. Někteří ale i po celoživotním pobytu v Americe si na americkou stravu ještě nezvykli a jedí v Americe to na co byli zvyklí doma.

Tudíž pokud se jídla týká, tak mnohé z nich typickou americkou stravou ani moc neuctíte, protože na ni možná nejsou ani zvyklí. Na co ale jsou všichni Američané zvyklí je vysoká úroveň služeb a které očekávají ve všech restauracích.

U Američanů se mi také nechce používat označení "turisté" Já vím, že nemám asi pravdu, ale turistu si představuji jako někoho s batohem na zádech, obutého do "pohorek", který přespává ve stanu nebo v autě a v tom nejlepším případě v nějaké turistické ubytovně nebo hostelu; prostě jako někoho, kdo za málo peněz chce poznat velký kus světa.

Neberte to ale tak, že tyto turisty znevažuji, právě naopak. Není na tom totiž nic špatného ani ponižujícího, nakonec já jsem se tak necestoval dost a dost, a takovýchto turistů k nám přichází většina a někteří dokonce i pěšky, a měli bychom si jich vážit jako každého jiného hosta.

Američané se ale od těchto "turistů" trochu liší. Oni k nám totiž většinou nepřichází jako "turisté", to je pěšky, autem nebo nějakým laciným dopravním prostředkem. Američané, pokud nedokáží tu velkou louži přeplavat, tak musí připlout buď lodí nebo přiletět letadlem, a to samo o sobě představuje již značný výdaj.

Američané k nám nemohou také přijet jen tak na večeři pak do opery, případně nakoupit žrádlo ro psa a vrátit se domů. Američané musí přijet nejméně na čtrnáct dní nebo nejlépe na tři neděle, na což mnozí musí obětovat více než svoji dovolenou a spolu s cestovným a případně s ušlým ziskem, je to relativně drahý výlet.

Nelze se proto divit, že za své dolary chtějí dostat, když nic jiného, tak alespoň slušné zacházení případně ucházející služby.

Tak jak Američany znám, tak většina je spokojená s málem, a to je úsměv, dobré pivo nebo víno, přičemž některým postačí i naše minerálka, a je jim jedno jestli jim to víno číšník nalévá zleva nebo zprava, a jestli při tom má ruku za zády, což je to jediné co se někteří naši absolventi hotelových škol s maturitou naučili. Američanovi stačí, když se na něj obsluhující alespoň usměje.

Američan také pochopí, že za půllitrovou láhev piva v předním hotelu musí zaplatit 100 korun (12 korun za pivo a 88 korun za to že mu ho nalijí zprava), ale nepochopí proč musí v některých restauracích platit za každou housku zvlášť, proč mu k ní nenabídnou alespoň máslo, proč není příloha již v ceně jídla a proč musí za ni musí platit zvlášť (à la carte), proč polévka stojí polovinu ceny hlavního jídla, a něco jako couvert mu nevysvětlíte ani půlhodinovou přednáškou.

Američan ale nepochopí proč jsou v poledne porce jídel a ceny stejné jako večer, proč mu i v poledne strkají v restauracích pod nos mísu s předkrmy, který každý stojí v průměru 20 korun, a kterých pokud není dost ostražitý mu dají na talíř alespoň dva nebo tří kousky. Proč mu nabízí v poledne aperitiv (z nějakého důvodu Campari vždy jako první), když vlastně chce zůstat střízlivý protože se po obědě ještě chystá užívat krásy naši země ve střízlivém stavu. Američan rád poznává cizí etnická jídla, a ze slušnosti pochválí i naši svíčkovou, přestože to není jeho "cup of tea", ale nepochopí, proč mu ji nutíme každý den, když on vyrostl na steacích a na hamburgrech.

Američan také nepochopí proč s ním v České republice většina obsluhujících jedná jako s naivním milionářem který právě vyskočil z filmu Dallas nebo Dynasty a který neví co s penězi.

Našinec prostě neví, že většina Američanů, mimo těch několika málo gangsterů, si musí své peníze tvrdě vydělat, a že o "tunelování" toho ještě moc nevědí.

Proto pokud čeští číšníci nebo servírky chtějí vyloudit úsměv na Američanově tváři, tak se s ním moc nesmí malovat. Musí se na něj usmát, dát mu co mu patří, zeptat se ho jak mu to chutná, a on jim určitě dá nakonec i slušný "tuzér" což je vlastně zkomolenina amerického "to serve", neboli za dobrou službu, protože je na to z domova zvyklý.

O stravovacích zvyklostech Američanů, o kterých si každý kdo tam alespoň týden byl si myslí že ví vše, si ale musíme jako studenti Hostovky říci něco více.

Mnoho lidí u nás si o Američanech se kterými se setkali si myslí, že jsou nároční, ale v zásadě je to jen díky jejich naivnosti ve které si myslí, že standard, na který jsou zvyklí doma, mohou očekávat i všude jinde.

Doma Američan ví, že se může v kterékoliv restauraci s rychlým občerstvením najíst za 2 až 3 dolary a že za tyto peníze mu v některé té restauraci dají i neomezené množství soft drinků, a jediné co ještě může očekávat je úsměv prodavačky, jednoduché, ale absolutně čisté prostředí včetně sociálních zařízení a to je vše.

To ale už znáte z těch několika amerických podniků rychlého občerstvení u nás, kterým vlastně vděčíme za to, že se několik našich mladých lidí naučilo to co je naše odborné školy nenaučily a to je pracovní disciplína a umění jak jednat se zákazníkem.

Američan ale také ví, že když si připlatí takových 5 až 6 dolarů, že v restauraci se stolovým zařízením a obsluhou mu nabídnou větší výběr jídel a nápojů, že ale obsluha, i když velice příjemná, bude o něco pomalejší.

Servírky se zde na něj také budou smát, jak zasedne tak mu přinesou kopec housek a másla (v ceně hlavního jídla), nalijí mu velkou sklenici vody s ledem (zadarmo), a jakmile mu donesou jídlo, tak se ho do nekonečna budou ptát jak mu to chutná, a jestli náhodou pro něj nemohou ještě něco udělat, jako například jestli nechce více pečiva nebo másla atd. Jídlo bude dobré, bude ho více než dost, a tak vlastně nemá na co by si mohl stěžovat - i kdyby chtěl. Nicméně když odchází tak se ho při placení manažer pro jistotu ještě jednou zeptá, jestli bylo vše v pořádku a požádá ho, aby přišel zas. What a country!

No, a to samé ve své naivitě ten Američan očekává i u nás. Jedno ale vím, a sice, že není zase tak naivní, že by v některé naší restauraci očekával ty samé služby a ta samá jídla jaká dostane v Americe v těch typických dražších restauracích nebo steakhouses, kde ovšem dá za večeři 20 až 30 dolarů (bez vína).

To ale nemluvím o tak zvaných luxusních restauracích, nebo privátních klubech (o kterých se nikde nemluví), ve kterých jsou jídla tak drahá, že se někde stydí dát ty ceny na svůj jídelní lístek a mají jídelní lístky bez cen. What a country!

Toto je ale jen bleskové popsání široké škály služeb a cen v amerických restauracích a to jen proto abyste pochopili Američanovu naivitu, při návštěvě našich restaurací.

Jinak se ale dá říci, že Američané se chovají ku svému tělu jako ku svému autu.

Američan když má Jaguára, Cadilac, Mercedes nebo jiné drahé auto, tak u pumpy ukáže palcem dozadu, kde má benzinovou nádrž, a řekne: "Fill it up with premium", což znamená, že mu ho mají naplnit tím nejlepším benzínem který mají. No, a své tělo "plní" také tak - když na to má, tak si dá ten největší steak třeba i za 20-25 dolarů a když na to nemá, tak si dá se stejnou chutí hamburgra za 90 centů. What a country!

Většina Američanů, včetně těch milionářů, vyrostla totiž na jídlech jako je hamburger, peanut butter sandwich, hot dog, fish fingers a případně smažená kuřata. O Američanech se také nedá říci, že by byli vybíraví, i když jsou jídla která nejedí, ale to je spíše proto, že se s nimi ještě nikdy nesetkali. Naštěstí takových jídel je málo.

Amerika je země imigrantů z celého světa. Každá etnická skupina sebou přinesla recepty na jídla na která byli doma zvyklí, a tak to byla jen otázka nalézt k jejich přípravě ty správné suroviny, a to dnes v Americe už také není žádný problém.

Je sice pravda že tu správnou mouku na knedlíky, nebo na typické české rohlíky v Americe všude nedostanete, ale ostatních surovin je velký výběr a to ve všech možných kvalitách.

Tím pádem ale dnešní americká kuchyně je směsice těch nejlepších jídel z celého světa u kterých se ale bohužel někdy již ani nedá zjistit kdy, odkud a kým byly do Ameriky přineseny.

Průměrný Američan si tímto ale hlavu moc neláme a prostě jí to co mu chutná protože si má z čeho vybrat.

Nu a vy, pokud někdy do Ameriky pojedete, tak do těch českých restaurací nechoďte, i když některé jsou lepší než podobné restaurace v Česku, ale vychutnejte to co doma nemáte, a hlavně dbejte na to, abyste za své dolary dostali to co vám patří.

