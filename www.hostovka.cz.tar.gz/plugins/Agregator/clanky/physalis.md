
{xml:lang="cs" ns="https://www.hostovka.cz" class="docinfo linklist" data-source="http://2017.hostovka.cz/clanek.php?clanek=127.html" data-og-image="/files/preview/clanky/physalis/general.jpg" data-og-type="article"}

{id="physalis" ctime="2005-12-22" author="Michael Klíma" short="Physalis" authorid="hostovka/michael_klima"}

# Physalis

{kw="zbožíznalství"}

Physalis se na českých trzích dnes objevuje velice často, ale já se obávám, že jen málo lidí ví co to vlastně je a jak physalis jíst nebo podávat.

Studenti Hostovky by ale takové věci měli vědět a proto vám physalis krátce popíši

Physalis má několik synonymů: Physalis capsicifolia, Physalis lanceifolia, Physalis ramosissima

V angličtině se na trzích objevuje jako: Mullaca, camapu, bolsa mullaca, cape gooseberry, wild tomato, winter cherry, juá-de-capote, capulí cimarrón, battre-autour, k'u chih, 'urmoa batoto bita, cecendet, dumadu harachan, hog weed, nvovo, polopa, saca-buche, thongtheng, tino-tino, topatop, wapotok

Physalis je jeno z mála ovoce ze kterého se používá celá roslina, plody, listy, a kořeny.

Mullaca si dlouho držela své místo v přírodní medicíně v tropických zemích ve kterých roste.

Používání physalisu jako jedlého sladkokyselého ovoce nejenom Indiány ale i zvěří v povodí Amazonky je dobře dokumentováno.

Domorodí Indiáni používají odvar z listů při zažívacích potížích.

Já jsem kolem ovoce physalis chodil hodně dlouho než jsem dostal odvahu ho ochutnat k tomu abych poznal co to vlastně je. Když se to tak vezme, tak to jako ovoce ani nevypadá. V té suché slupce to spíše vypadá jako nějaká květina.

Měl jsem ho v kuchyni po nějaký čas a stále se mi do toho moc nechtělo.

#IMG \[http://2017.hostovka.cz/soubor/22-12-05-2.jpg\] \[Physalis\]

Když ale se pak ta slupka otevře, tak vidíte, že uvnitř je plod velikosti velkého hroznového vína, lesklé a trochu lepkavé s velice příjemno vůní takže nakonec neodoláte a ochutnáte ho.

Ta slupka slouží k tomu ji uchopit mezi prsty tak abyste mohli to ovoce pohodlněji jíst.

To ovoce tak říkajíce "skočí" do vašich úst a překvapí vás fantastickou unikátní chutí takže si říkáte proč jste ho neochutnali již dávno před tím.

Ovoce je pevné, šťavnaté a sladké s překvapujicí kyselostí která hraničí s kožřenovu chutí. Pro upřesnění tohoto popisu musím říci, že to není nějaká nezapomenutelná chuť jako chuť ananasu nebo pomeranče.

Phylsalis je také známé jak cape goosberry což jeho chuť vyjadřuje nejlépe ale přesto physalis má svoji osobitou chuť.

Prostě pokud to v nějakém supermarketu uvidíte, tak si ho kupte protože to stojí za ochutnání

