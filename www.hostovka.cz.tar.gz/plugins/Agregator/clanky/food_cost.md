
{xml:lang="cs" ns="https://www.hostovka.cz" class="docinfo linklist" data-source="http://2017.hostovka.cz/clanek.php?clanek=392.html" data-og-image="files/preview/clanky/food_cost/general.jpg" data-og-type="article"}

{id="food\_cost" ctime="2009-04-09" author="Michael Klíma" short="Food Cost" authorid="hostovka/michael\_klima"}

# Food Cost

{kw="kdo-kdy-kde"}

To co blábolí o food cost ve svém pořadu Ano šéfe náš samozvaný nejvyšší kuchař Zdeňek Pohlreich tomu nevěřte. Musíte si o tom něco přečíst, abyste viděli že jsou to všechno nesmysle. Pokud si to řekneme velice zjednodušeně a laicky, tak Food cost je anglický výraz pro náklady na výrobu jídel které jsou vyjádřeny v procentech v poměru k jejich prodejní ceně.

Food cost, zkráceně FC, je různý podle charakteru a cenové skupiny dané restaurace. Nejnižší FC mívají restaurace nižších cenových skupin a restaurace rychlého občerstvení (Fast food) ve kterých se FC pohybuje mezi 17-30 %.

Ideální průměrný FC běžných restaurací je 33 %, což v praxi znamená, že potraviny nakoupené za 1 Kč, se musí prodat za 3 Kč.

V drahých či luxusních restauracích, které používají drahé potraviny, FC 50 % není nic neobvyklého a není to výraz špatného hospodaření.

V americkém pohostinství FC je zaklínadlo, kterému je ale věnována nezasloužená pozornost. FC podobně jako Labor cost (LC) je do značné míry ovlivňován odborným ekonomickým zpracování potravin a celkovým know how.

Vytvoření ideálního FC pro zabezpečení dobrého hospodářského výsleku není tak jednoduché jak se zdá, což je dobře, protože to by do toho pohostinství skutečně fušoval kde kdo. Tvorbou ideálního FC se bude zabývat jeden z připravovaných seminářů výchovného střediska STEAKGRILLEDU™.

