
{xml:lang="cs" ns="https://www.hostovka.cz" class="docinfo linklist" data-source="http://2017.hostovka.cz/clanek.php?clanek=107.html" data-og-image="/files/preview/clanky/koktejly/general.jpg" data-og-type="article"}

{id="koktejly" ctime="2005-11-12" author="Michael Klíma" short="Koktejly" authorid="hostovka/michael_klima"}

# Koktejly

{kw="nápoje"}

Pocházím z relativně malého vojenského města kde byla jen samá kasárna a jinak nic než samá hospoda, jedna hospoda vedle druhé.

Do jedné té hospody jsem jako kluk chodil často se džbánem tatínkovi pro pivo takže jsem vlastně již od útlého mládí měl vztah k pohostinství.

Z toho džbánu jsem cestou občas upíjel tudíž jsem byl již jakýsi odborník na pivo.O něčem takovém jako koktejly jsem tehdy ale nic neslyšel a jsem přesvědčen, že to nevěděl ani jeden z těch čtyřiceti hospodských které jsme v našem městě měli.

Potom jsem se ale začal učit v Praze v hotelu Alcron, kde jsem teprve viděl, že přesto že jsem v pohostinství již určitou praxi měl, že do odborníka to mám ještě hodně daleko.

To víte, koukala mi ještě sláma z bot a proto jsem přímo fascinován se vším c čím jsem se v tom hotelu setkal a musím se přiznat že nejvíce snad tím barem který jsme tam měli.

Ten bar byl plný lahví všemožných likérů a jiných lihovin a krásných skleniček které jsem ale moc rád neměl, protože jsem je musel denně ručně v horké vodě umývat.

Když jsem ty skleničky od těch drinků (tehdy jsem nevěděl, že se tomu tak říká), dal do té horké vody, tak to všechno od těch Bolsů tak krásně vonělo a tím jsem k tomu barmanství nebo mixování vlastně "přičichl".

Občas jsem se díval na barmana Karla Kroupu, zvaného Charlie, o kterém jsem si ve svých 14 letech myslel, že je největším barmanem na světě. Pozoroval jsem ho když mixoval některé ty cocktaily a snil jsem o tom, že jednoho dne budu také takový slavným barmanem jako je on.

Musím vám ale říci, že tento sen se mi nikdy nesplnil protože člověk míní, a osud mění.

Pohostinství se ale stalo mým koníčkem a když jsem trochu povyrostl, a viděl jsem na ten bar pult, tak jsem za účelem lepšího porozumění barmanství začal "vymetat" všechny pražské noční lokály od těch luxusních až po ty pajzly, jal se jim odborně říkalo, a moje odbornost díky tomu nepředstavitelně vzrostla a to hlavě z toho důvodu, že jsem se na to barmanství naučil dívat spíše z pohledu hosta než z pohledu barmana.

Poznal jsem celou řadu barmanů v Est baru, Barberině, Boccaciu, u 5-P (s těmi telefony), Sekt pavilonu, v Baroku, Rokoku a nevím jak se všechny ty noční zapadáky jmenovaly a mohu vám říci, že jsem přišel na to, že ti barmani byli většinou stejně dobří jako byl Charlie.

Když jsem ale pak po válce přišel do Paříže a později do Alžíru, Tunisu, Bizerty a dokonce do Saigonu, kterému se tehdy říkalo Paříž Blízkého Východu, a viděl jsem i jiné bary a barmany, tak mně ta touha stát se barmanem opět popadla.

V Paříži jsem si koupil moji první knihu o koktejlech "COCKTAIL de PARIS, PRESENTÉS PAR RIP, ILUSTRÉ PA PAUL COLIN", kterou ještě mám, ale moje francouzština tehdy nebyla tak dobrá abych uměl srovnávat a rozeznat, že to bylo všechno zřejmě opsané z nějakého amerického originálu.

Po návratu do Česka jsem si pak později koupil moji druhou barmanskou knížku od Harryho Schraemli DAS GROSSE LEHRBUCH DER BAR a musím říci, že jsem se studiem barmanství začal opět váženě zabývat. Dokonce jsem si udělal barmanský kurz u Harryho Reimanna, který protože měl praxi v Americe byl v té době také považován za mistra světa, ale o kterém dnes po tolikaletém pobytu v Americe vím, že jako mnoho jemu podobných byl prachobyčejný showman.

Později na hotelové škole v Mariánských lázních jsem také absolvoval další barmanský kurz a dalo by se tudíž předpokládat že jsem byl dostatečně odborně vzdělaný, ale musím se přiznat, že mimo občasného fušování do této profese jsem barmana nikdy nedělal.

Víte, s tím barmanstvím je to totiž tak, že to musíte dělat nepřetržitě denně a to bez ohledu na to jestli je to v Praze, v Brně, v Pekingu na rynku neb třeba i v Novém Yorku. To barmanství má totiž sice své zásady a nepsané zákony a ty jsou v každém baru trochu jiné a sice podle klientely.

Byl jsem kdysi majitelem jedné české hospody v Ciceru, což je česká čtvrť na předměstí Chicaga a tam mi ale mé chabé barmanský vědomosti přišly vhod když mi jednoho dne nepřišel do práce můj barman. Musel jsem za ten bar sám a nemáte ponětí co se za tím barem ten den dílo. Moje klientela byla zvyklá na své oblíbené drinky které dobře znali protože nic jiného nepili a tak prostě nic nebylo come il faut a nebýt toho, že to naše jídlo nemělo chybu, tak mnozí by k nám bývali již nikdy ani nepáchli. Prostě každá věc chce své a podle mého créda musíte hostům dát co jim patří.

Asi tak v padesátých letech jsem zaslechl, že v Zurichu na letišti, které bylo tehdy křižovatkou všech mezinárodních letů, jsou barmani, kteří díky té mezinárodní klientele jsou schopni připravit jakýkoliv drink který vůbec existuje. Měl jsem v té době příležitost se do toho baru podívat a tak jsem to celé tajemství rozluštil.

Ano, pokud přiletěl host třeba i z Tokia, Číny nebo i z Ameriky a požadoval jakýkoliv drink, tak musel těm barmanům říci jen název toho drinku a případně hlavní ingredienci. Tehdy počítače ještě nebyly a tak pokud ten drink ti barmani neznali, tak šáhli pod pult, kde měli lexikony všech drinků které byli kdy publikovány, a když recept na ten drink našli, tak ho tomu hostu udělali. Jestliže ale ten drink nikdy publikován nebyl, tak ten host měl prostě smůlu.

No, a to jsme opět u té klientely. Kdysi barmani byli staří ostřílení bojovníci a většinou viděli svým hostům nejenom do kapsy ale i do žaludku a věděli s kým mají co činit a znali své pappenheimské takže při objednávce jakéhokoliv drinku věděli který host jen blafuje nebo se jen rozcapuje, a kdy se jedná o hosta který těm drinkům skutečně rozumí.

Dnes ale, až na nějaké výjimky, dělá to barmanství kde kdo a o lihovinách a koktejlech a jiných drincích nemusí vědět vůbec nic a stačí jen když je dobrý žonglér nebo komediant (taky umění).

V Americe například mnozí barmani jsou policajti kteří to dělají "na vedlejšák" v době svého volna. Barmanstvím se také čím dále tím více zabývají i ženy a zde je to něco podobného.

Já proti barmankám nic nemám, ba naopak, ale mnohé z nich toho o barmanství moc nevědí a proto to dohoní svým "decolté". Ve světě jsou i bary kde ty barmanky jsou "topless", ale některé toho o barmanství vědí tak málo že by podle mě za tím barem mohly být i nahaté a nic by jim to nepomohlo.

Já také nemám nic proti mladým lidem, protože i když se to zdá být neuvěřitelné, tak já jsem kdysi byl také mladý a navíc téměř celý život pracuji s mladými lidmi, ale přesto si myslím že nějaká "zralost" (maturity), je k tomu barmanství potřeba.

Prostě si myslím, že to s těmi "mladými" barmany a someliéry trochu přeháníme. Já také nemám nic proti ambiciosním mladým lidem, nakonec já jsem tam kde jsem také jen díky mým ambicím, ale obávám se, že některým těm našim mladým barmanům ty odměny, ceny a medaile při těch soutěžích stouply moc do hlavy.

Teď mně ale napadlo, že to co vám tady o koktejlech píši vas ani možná nezajímá a že byste raději viděli nějaké receptury.

Já na to že nejsem barman mám relativně dobrou odbornou barmanskou literaturu ve všech řečech ve které, jako ti barmani v tom Zurichu, jsem schopen nalézt jakýkoliv drink, ale mohu vám říci, že dnes tím že mám počítač a přístup k internetu vidím, že všechny ty knížky byly vyhozené peníze.

Těch drinků je dnes totiž na internetu tolik, že je mi až líto, každého autora který se dnes snaží nějaké drinky publikovat knižně. Všichni lidé ale počítač ještě nemají a tak některé ty knížky přijdou vhod, ale nějakou budoucnost to nemá.

Nechci ale aby ta moje sbírka a moje barmanské zkušenosti přišly úplně nazmar a tak pokud máte nějaké dotazy ohledně barů a drinků, tak mi je neváhejte položit.

Já pokud se týká pohostinství mám odpověď na všechno a pokud ne, tak si prostě něco vymyslím.

Ale i tak budu do této sekce dávat příspěvky které by vás jako studenty Hostovky mohly zajímat.

