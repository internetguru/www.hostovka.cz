
{xml:lang="cs" ns="https://www.hostovka.cz" class="docinfo linklist" data-source="http://2017.hostovka.cz/clanek.php?clanek=178.html" data-og-image="files/preview/clanky/barding_house/general.jpg" data-og-type="article"}

{id="boarding\_house" ctime="2006-09-22" author="Michael Klíma" short="Boarding House" authorid="hostovka/michael\_klima"}

# Boarding House

{kw="ubytování"}

Ve Spojených státech se Boarding house kdysi také někdy nazýval "rooming house", nebo také "lodging" house, ale všechny tyto výrazy v tom původním poslání upadají v zapomenutí. "Board" má v angličtině několik významů a jeden z nich je strava, tudíž v tom názvu Boarding house se o ubytování nemluví.

Stejné množství významů má slovo "room", a v tomto případě znamená pokoj, neboli ubytování, a to samé platí ale o "lodging" neboli ubytování.

Všechny tyto výrazy přišly do Ameriky z Anglie, kde se dodnes běžné používají. Bylo to ubytování v privátních domech a to někdy na delší dobu, někdy i na několik let, něco podobného jako u nás podnájem.

Koupelny či umývárny byly společné stejně tak jako toalety a společné bylo i stravování což ve většině případů byla jen snídaně, ale mnohdy i oběd nebo i celodenní strava.

V Anglii tyto domy většinou spravovaly ženy, "boarding ladies" které ve většině případů při delší době ubytování poskytovaly i praní prádla což bývalo i u nás součástí podnájmu, podobně jako někdejší naše podnájmy kterým se tehdy říkalo "s mýdlem", což ale mělo i jiný význam, který tady popisovat nemohu.

V boarding houses se jedlo ve společné jídelně a jídlo se podávalo tak zvaným "family style" neboli rodinným způsobem na mísách které se zakládaly doprostřed stolu, ze kterých si hosté (borders) brali jídla sami, kterýžto způsob se zachoval v některých amerických restauracích dodnes a používá se většinou při svatbách nebo podobných rodinných příležitostech.

Boarding houses se v Anglii zachovaly dodnes, i když se poněkud zmodernizovaly, a dá se říci že u některých lidí jsou stále ještě oblíbené.

V Americe se dnes pod názvem Bording houses většinou rozumí ubytovny pro studenty kde je jim mimo ubytování a stravování věnována pečovatelská péče podobně jako na našich internátech.

Pro ostatní boarders ale tento typ ubytování v privátě byl nahrazen B&B, což je zkratka pro Bed and Breakfast (postel a snídaně) což poněkud přesněji vyjadřuje jejich poslání.

Nabízejí se v různých kategoriích od těch nejjednodušších až po ty luxusní, které jsou mnohdy dražší než některé hotely. Jsou oblíbeny u rodin z dětmi, protož mají jakési soukromí od typického hotelového života, nebo u některých bohatých lidí kterým jdou hotely na nervy.

Na Hawaji, kde ubytování je relativně drahé, je tento způsob oblíbený u pracovníků v hotelích a u sezónních pracovníků.

Koncept B&B nebo ekvivalent britských boarding houses, je rozšířený po celém světě i když mnohdy pod jiným názvem.



Například japonské minshuku, jsou téměř stejné jako jiné B&B, ale vyznačují se pověstnou až chorobnou péčí o čistotu a hygienu. Američani si v zásadě na hygienu také potrpí a někteří se sprchují až dvakrát denně, ale v některých zemích kdyby jim to občasné mytí nenařizovalo jejich náboženství by se nemyli třeba i celý rok.

Proto Japonci jsou při vybírání svých "boarders" dosti opatrní.

Oproti tomu v Česku v té porevoluční euforii a při tom nedostatku ubytování hlavně v Praze, lidem prošlo všechno možné. Prostě lidé kteří nikdy mimo svého bytu v žádném B&B, natožpak v nějakém pořádném hotelu v zahraničí nikdy nespali šířili do světa naši představu o kultuře bydlení.

Někteří sice nevěděli co jejich hostům za jejich peníze patří, ala na druhé straně, na výpadovkách na Německo jste se setkali (a možná ještě setkáte) že za příplatek dostanete k té snídani ještě masáž. V takovém případě by měli mít na domě buď červenou lucernu a nebo k tomu B&B přidat ještě jedno B, nebo ještě lépe P (pro německý Puff).

Já vím, že by mně hned někdo mohl napadnout, že urážím Čechy a tak musím hned dodat, že byly a jsou výjimky, ale musel jsem vám jako studentům Hostovky toto napsat.

