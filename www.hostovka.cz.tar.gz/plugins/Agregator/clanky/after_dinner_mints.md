
{xml:lang="cs" ns="https://www.hostovka.cz" class="docinfo linklist" data-source="http://2017.hostovka.cz/clanek.php?clanek=151.html" data-og-image="/files/preview/clanky/after\_dinner\_mints/general.jpg" data-og-type="article"}

{id="after\_dinner\_mints" ctime="2006-05-22" author="Michael Klíma" short="After dinner mints" authorid="hostovka/michael_klima"}

# After dinner mints

{kw="etika"}

Myslím si, že vám dlužím vysvětlení toho co jsou to after dinner mints o kterých jsem se zmínil v mém příspěvku o párátkách.

After dinner mints jsou více méně americký vynález. Francouzi mají ale něco podobného. Říkají tomu friandises.

Francouzské friandises jsou kousky nebo sousta něčeho sladkého, jako například čokoládové bonbony nebo jahody v čokoládě, apod., které se v lepších restauracích ať již ve Francii nebo v Americe podávají nakonec stolování jakoby pozornost podniku, neboli "na dům".

Podobným způsobem se i v Americe podávaly after dinner mints které mají osvěžit ústa po jídle, obzvláště po jídle nějakých pokrmů s výraznou chutí a to nejenom v restauracích ale i v domácnostech.

V domácnostech se tento zvyk stále ještě drží a některé hostitelky se předhánějí v jejich nabídce a jsou schopni na nich utratit velké peníze.

Velice módní jsou belgické čokoládové bonbony.

{class="figure"}

![čokoládový bonbon 1][1] 
:   čokoládový bonbon 1

{class="figure"}

![čokoládový bonbon 2][2] 
:   čokoládový bonbon 2

{class="figure"}

![čokoládový bonbon 3][3] 
:   čokoládový bonbon 3

Ale jako by toho nebylo dost tak dnes dostanete skoro stejně dobré bonbony z Venezuely.

{class="figure"}

![bonboniéra][4] 
:   bonboniéra

Tudíž z prodeje friandises se stal velký byznys. Nicméně after dinner mints podávané v restauracích také neztratily svoji popularitu, ale jako vše, tak i toto se poněkud zjednodušilo. Ve většině restaurací jsou ty after dinner mints u východu z restaurace, zpravidla na pultíku hostesky, kde si jich každý host při odchodu může vzít kolik chce, jako těch párátek. What a counry!

Možná že si řeknete jak to ti američtí restauratéři mohou dělat, že dávají tolik věcí zadarmo, ale nemějte obavy. Je sice pravda, že některý host si těch after dinner mints vezme plnou hrst, ale někteří si je vůbec nevezmou a tak ono se to vyrovná, nehledě k tomu, že ty "zadarmo" skutečné skutečně za moc nestojí.

Já jsem podávání after dinner mints doporučil Jardovi Honzajkovi, majiteli restaurace Steakgrill v Račiněvsi a restaurace Pod Hláskou v Roudnici, ale jak jse se dozvěděl, tak jen velmi málo hostů to ocenilo protože to v Česku není ještě zvykem, a někteří hosté nevědí že pravý důvod jejich podávání je aby si hosté osvěžili dech po jídle.

 [1]: http://2017.hostovka.cz/soubor/22-5-06-1.jpg
 [2]: http://2017.hostovka.cz/soubor/22-5-06-2.jpg
 [3]: http://2017.hostovka.cz/soubor/22-5-06-3.jpg
 [4]: http://2017.hostovka.cz/soubor/22-5-06-6.jpg

