
{xml:lang="cs" ns="https://www.hostovka.cz" class="docinfo linklist" data-source="http://2017.hostovka.cz/clanek.php?clanek=134.html" data-og-image="/files/preview/clanky/rocky\_mountains\_oysters/general.jpg" data-og-type="article"}

{id="rocky\_mountains\_oysters" ctime="2006-02-01" author="Michael Klíma" short="Rocky mountain oysters" authorid="hostovka/michael_klima"}

# Rocky mountain oysters

{kw="jídla a jídelní lístky"}

Když neznáte názvy vašich oblíbených jídel v cizích jazycích tak si v cizině kolikrát ani nemůžete podle vaši chutě objednat přesto, že ta jídla jsou tam známá ale pod jiným jménem.

Některým jídlům se dávají přitažlivá jména která ale nemají vůbec co společného s použitou surovinou neb technikou jejích přípravy.

Příkladem jsou americké Rocky Mountain Oysters, což nemá co společného s ústřicemi ani se Skalnatými horami. Rocky Mountain Oysters jsou v Americe velice oblíbené a každý gurmán ví co to je, a díky Hostovce to budete teď vědět i vy.

V Česku se jim říká Býčí láska, což je již tak trochu přiléhavější, ale i tak je spousta lidí kteří je jedí a při tom nevědí co to je.

Jsou to prach obyčejná býčí varlata která by se ale pod tím názvem moc neprodávala a proto ta zavádějící (nebo navádějící) jména.

Já je pod názvem Býčí láska znám ještě z Česka. Chodil jsem na ně do Konibaru ve Vodičkové ulici ale objevil jsem je nakonec i tady v Tijuaně v Mexiku, hned vedle býčího rodea, což je asi tak hodina jízdy od mého baráku.

Já do Tijuany občas jedu, ale ne na býčí zápasy, ale na ty ústřice které jsou tam vždycky čerstvé a hlavně velké.

Já si v restauracích moc nestěžuji, ale jednou mi tam podali dva takové prcky, že jsem musel zavolat číšníka a na tu velikost jsem si stěžoval.

Ten číšník mi to vysvětlil. Řekl mi totiž, že asi dobře vím že býčí zápasy (ze kterých oni ty "ústřice" dostávali, jsou velice riskantní a nevyzpytatelný byznys a že prostě někdy to vyhraje ten býk.

