
{xml:lang="cs" ns="https://www.hostovka.cz" class="docinfo linklist" data-source="http://2017.hostovka.cz/clanek.php?clanek=115.html" data-og-image="files/preview/clanky/zkratky\_na\_listcich/general.jpg" data-og-type="article"}

{id="zkratky\_na\_listcich" ctime="2005-11-23" author="Michael Klíma" short="Zkratky na lístcích" authorid="hostovka/michael_klima"}

# Zkratky na jídelních lístcích

{kw="jídla a jídelní lístky"}

Učit české restauratéry jak psát jídelní lístky jsem po několikaletém úsilí více méně vzdal. Založením Hostovky ale považuji za jakousi morální povinnost naučit mé studenty jak české jídelní lístky číst což je někdy jisté umění.

Tentokrát ale nehovořím o všech těch možný a nemožných názvech jídel kterým nerozumí ani ti kteří ty názvy na jídelní lístek dávají.

Nikdo neočekává, že by jídelní lístek měl být ukázkou nějaké literární schopností jeho tvůrce. Hosté mimo jiné nechodí do restaurací proto, aby strávili většinu času čtením nezáživných informací o původu restaurace nebo o těžkých začátcích pana majitele.

Hoste také chápou, že každý milimetr místa na jídelním lístku má nesmírnou cenu a proto že údaje na lísku musí být popisné a stručné.

S tou stručností se to však nesmí přehánět. Na našich jídelních lístcích se totiž setkáme i s takovými údaji jako: Biftek s vej., sm. Br.hran. m.m.;čer.zel.m.obl., čemuž jako student Hostovky musíte rozumět jako: Biftek s vejcem, smažené bramborové hranolky, máslem maštěná čerstvá zelenina, malá obloha.

Občas se v odborném tisku objeví kritika jazykové přesnosti jídelních lístků, ale zkratky na jídelních lístcích jsou úplně jiné zvíře a já jsem překvapen, že žádný z těch puristů je zatím tento nešvar nikdy nekritizoval.

Je to podle mně zmatek zkratek a pokud se naši hosté v těchto značkách nevyznají, tak to není díky jejich nedostatečné inteligence, ale nedostatek inteligence jejich tvůrců.

