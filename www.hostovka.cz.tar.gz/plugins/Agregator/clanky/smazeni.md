
{xml:lang="cs" ns="https://www.hostovka.cz" class="docinfo linklist" data-source="http://2017.hostovka.cz/clanek.php?clanek=87.html" data-og-image="files/preview/clanky/smazeni/general.jpg" data-og-type="article"}

{id="smazeni" ctime="2005-10-30" author="Michael Klíma" short="Smažení" authorid="hostovka/michael_klima"}

# Smažení

{kw="kuchyňské techniky"}

Jedna z důležitých kuchyňských technik je smažení, které spadá mezi techniky přípravy jídel na tuku nebo v tuku. Tato technika je popsána v milionu kuchařských knih a vyučuje se na všech odborných školách a proto vám ji tady popisovat nebudu, ale pokud se týká jídelních lístků, tak na těch je hodně o tom smažení zanedbáno.

Napsat na lístek jen, že některý pokrm je smažený, totiž nestačí.

Smažený, anglicky fried, francouzsky frit, italsky fritto, španělsky a portugalsky fresco, jak vidíte se velmi podobá, ale zrovna tak se podobají hodinky a holinky. Rozdíl je v němčině kde smažený je gebraten, a v srbštině, kde smažený je pržen.

Ono ale záleží jestli ten pokrm byl smažený jen na malé vrstvě tuku jako jsou například smažená vejce, nebo smaženice, nebo jestli byl smažený v hlubokém tuku (deep fried), nebo na pánvi (pan-fried), nebo ve fritéze, protože někteří lidé ten tuk nemají moc rádi.

Ale ono také záleží jestli ta potravina je obalena jen moukou, trojbalem, nebo zda byla namočena v těstíčku. Potraviny obalené trojblem (braded) jako například řízky se dají smažit dokonce i v konvektomatu a nebo jenom v troubě, ale já to nemám moc rád. Výjimku tvoří obalovaná kuřata nebo ryby, ale v angličtině se v tom případě neříká že tyto potraviny byly fried, ale baked, což jsme si již vysvětlili když jsme hovořili o grilování.

Tudíž teď jako studenti Hostovky víte, že pokud to smažení na jídelním lístku není přesně specifikováno, že byste se na to měli zeptat a doufat, že to ten obsluhující ví.

