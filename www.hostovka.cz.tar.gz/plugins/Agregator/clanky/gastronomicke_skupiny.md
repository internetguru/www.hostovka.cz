
{xml:lang="cs" ns="https://www.hostovka.cz" class="docinfo linklist" data-source="http://2017.hostovka.cz/clanek.php?clanek=106.html" data-og-image="files/preview/clanky/gastronomicke_skupiny/general.jpg" data-og-type="article"}

{id="gastronomicke\_skupiny" ctime="2005-11-10" author="Michael Klíma" short="Gastronomické skupiny" authorid="hostovka/michael\_klima"}

# Gastronomické skupiny na českých lístcích

{kw="jídla a jídelní lístky"}

O názvech jídel jsme si v této sekci již něco řekli, ale o čem by studenti Hostovky něco měli vědět jsou gastronomické skupiny. Nemám ale na mysli gastronomické skupiny do kterých se jídla dělí tak aby v nich byl nějaký přehled, mám na mysli gastronomické skupiny se kterými se setkávají hosté na jídelních lístcích.

Dal jsem si s tím práci a sepsal jsem gastronomické skupiny se kterými se setkáváme na Českých a nejspíše i na Slovenských jídelních lístcích:

  * Bezmasá a zapékaná jídla
  * Bezmasá jídla
  * Bifteky
  * Co tak něco na zub
  * Dětské jídelní lístky
  * Drůbež
  * Hotová jídla (Hotovky)
  * Chlebové papačky
  * Jehněčí maso
  * Jídla na objedávku

  * Jídla pro celou rodinu
  * Kompoty
  * Masové směsi
  * Moučníky
  * Něco k zakousnutí
  * Něco pro štíhlou línii
  * Osvěžující saláty
  * Poháry, zmrzliny a moučníky
  * Pokrmy k pivu a k jiným mokům

  * Pokrmy na grilu
  * Polévky
  * Předkrmy
  * Přílohy
  * Rybí speciality
  * Ryby
  * Saláty
  * Slovanská kuchyně

  * Speciality
  * Speciality na grilu
  * Speciality naší kuchyně
  * Speciality z bramborového těsta
  * Speciality z hovězí svíčkové
  * Steaky
  * Studená jídla
  * Studené předkrmy
  * Sýry
  * Teplé nápoje

  * Teplé omáčky
  * Teplé předkrmy
  * Těstoviny
  * Vepřové maso
  * Vepřové speciality

Já jsem ty skupiny neočísloval, ale nemusíte je počítat, je jich 47.

Toto je jen seznam sestavený z jídelních lístků jen několika málo restaurací a nemusím vám tudíž říkat že, těch skupin je na českých a slovenských jídelních lístcích daleko více.

Jedno ale musím říci, že na jednom lístku je všechny nenajdete ale je jich na těch našich jídelních lístcích více než dost a tak vidíte, jak je to všechno nesmyslné.

Také je nutno říci, že ten seznam je v abecedním pořádku a že na jídelních lístcích jsou ty skupiny v jiném pořadí.

Počet jídel v jednotlivých skupinách také není stejný. V Některé skupině jsou někdy jen dvě jídla, takže se člověk divý, že ta jídla mají vlastní skupinu, ale na druhé straně v některé skupině je jich 15 i více.

Tím se ale dostávám k hlavnímu důvodu pro který vám tento příspěvek píši. Jako studenti Hostovky musíte totiž být bdělí a ostražití.

Když v nějaké restauraci mají například 50-60 míst a navíc ta restaurace je poloprázdná a na jídelním lístku vidíte 10 hotovek, tak si musíte nutně položit otázku, kolik porcí od každé té hotovky asi uvařili. Kdyby uvařili jen pět porcí tak by to bylo více než je potřeba.

To ale platí i o těch jídel na objednávku. Tam zase když vidíte že jich mají také deset, tak je vám hned jasné že pokud je vás 6 nebo více si musíte všichni objednat jedno a samé jídlo protože kdybyste si objednal každý něco jiného, tak byste se vaši objednávky nikdy nedočkali.

Také když mají na lístku více než tři polévky, z nichž dvě jsou třeba již při otevření přeškrtnuté, tak vidíte, že něco v té restauraci nehraje. No a když navíc z té obrovské nabídky jídel jsou některá také již přeškrtnutá, tak byste se měli sebrat a jít někam jinam.

No, a teď jako obyčejně mi někdo napíše, že urážímm české kuchaře, ale " Who cares!",já jim prostě nedám pokoj dokud se nepolepší.

