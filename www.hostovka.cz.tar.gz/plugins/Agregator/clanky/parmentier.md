
{xml:lang="cs" ns="https://www.hostovka.cz" class="docinfo linklist" data-source="http://2017.hostovka.cz/clanek.php?clanek=339.html" data-og-image="files/preview/clanky/parmentier/general.jpg" data-og-type="article"}

{id="parmentier" ctime="2008-06-29" author="Michael Klíma" short="Parmentier" authorid="hostovka/michael_klima"}

# Parmentier

{kw="kdo-kdy-kde"}

Antoine-Augustin Parmentier (Montdidier srpen 12, 1737, prosinec 13, 1813). Francouzský agronom a ekonom který mimo jiné ve Francii a v Evropě zpopularizoval brambory.

V roce 1748 pruský král Fridrich II., pod přísnými tresty ukládal sedlákům pěstovat brambory k čemuž jim dokonce dodával setbu, kdežto francouzský parlament pěstování brambor zakazoval s odůvodněním, že pojídání brambor způsobuje lepru.

Tento zákaz byl zrušen teprve díky Parmentierovi po kterém následně bylo pojmenováno velké množství jídel z brambor.

Pokud máte smysl pro humor, tak vám mohu napsat, že nejslavnější jídlo pojemenované po Parmentierovi je moje vepřová panenka parmentier.

