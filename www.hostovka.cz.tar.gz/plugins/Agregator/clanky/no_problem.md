
{xml:lang="cs" ns="https://www.hostovka.cz" class="docinfo linklist" data-source="http://2017.hostovka.cz/clanek.php?clanek=445.html" data-og-image="files/preview/clanky/no_problem/general.jpg" data-og-type="article"}

{id="no\_problem" ctime="2009-06-16" author="Michael Klíma" short="No Problem" authorid="hostovka/michael\_klima"}

# No Problem

{kw="případová studie"}

V konceptu STEAKGRILL® nemáme problémy ale úkoly. Žádný úkol není nesplnitelný musíme však vědět jak na něj, neboli že musíme mít potřebný know how, potřebnou sebedůvěru a potřebný drive. Nemohu o sobě říci, že bych neměl sebedůvěru, ale přesto jsem kdysi viděl problémy tam kde žádné vlastně nebyly.

Nicméně v Americe jsem se od jedné servírky jednoho dne naučil, že to co jsem viděl jako problém jsou vlastně chalenges, neboli úkoly. 

Jmenovala se Linda a přijal jsem ji jen proto, že na mně udělala dobrý dojem tím, že se stále usmívala.

Linda nebyla vyučená, natožpak aby byla absolventkou nějaké věhlasné české hotelové školy, ale přesto byla ta nejlepší servírka se kterou jsem kdy poznal a nemusím vám asi říkat, že během mé 60 leté mezinárodní praxe jsem jich poznal hezkou řádku.

Linda se od rána do večera usmívala, byla oblíbená u hostů, a přesto, že než u mě nastoupila o pohostinství nic nevěděla, dělala vše ochotně a na každý nový úkol řekla: „No problem“, což abych řekl pravdu, mně někdy až zaráželo.

Po nějakém čase, kdy už jsem Lindu dobře znal a věděl o ni téměř všechno, jsem to již nevydržel a musel jsem se Lindy zeptat, v čem je tajemství jejího kladného přístupu i k situacím, které jsem já považoval za problémové.

Řekl jsem Lindě, že vím že je rozvedená, že má dvě malé děti a každé s jiným tatínkem, že byla kdysi na drogách, že ji vyhodili z bytu protože dlužila za půl roku nájemné a že je v hrozném podnájmu, že ji vzali auto protože neplatila splátky, že ji nikdo nedá kreditní kartu, a že má zřejmě ještě celou řadu problémů o kterých možná neví ani ona sama.

Načež mi Linda řekla něco co nikdy nezapomenu a co jsem vlastně převzal jako mé krédo.

Linda mi řekla, že to co já vidím jako problémy pro ni vlastně problémy nejsou, protože to je bohužel skutečnost ve které žije.

Linda mi ale řekla, že si uvědomila, že takto dále žít nemůže a proto že na každý zdánlivý problém se musí dívat jako na úkol který musí vyřešit.

