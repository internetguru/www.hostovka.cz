
{xml:lang="cs" ns="https://www.hostovka.cz" class="docinfo linklist" data-source="http://2017.hostovka.cz/clanek.php?clanek=141.html" data-og-image="/files/preview/clanky/nezname_potraviny/general.jpg" data-og-type="article"}

{id="nezname\_potraviny" ctime="2006-03-15" author="Michael Klíma" short="Neznámé potraviny" authorid="hostovka/michael\_klima"}

# Neznámé potraviny

{kw="gastronomie"}

Opravte mně jestli se mýlím, ale já se domnívám že málo který průměrný návštěvník české či slovenské restaurace má bez podrobnějšího popisu představy o tom co to je argula, awabi, balsamický ocet, broiler, brusketa, calamari, cannelloni, carpacio, coulis, crudité, crusta, hřebenatky, řapíkatý celer, konfit, křupinka, mantl soufflé, terč, wasabi, a to jsem vyjmenoval jen pár těch výrazů které se na některých českých či slovenských jídelních lístcích objevují bez jakéhokoliv vysvětlení.

Prostě na jedné straně někteří podnikatelé dělají ze svých hostů úplné negramoty a na druhé straně od nich očekávají, že by toho o gastronomii měli vědět více než oni sami nebo jejich zaměstnanci.

To ale nemluvím o názvech jídel se kterými se dnes našinec setká na jídelních lístcích při svých cestách do zahraničí.

To ale také nemluvím o kuchařských technikách ať již v jakékoliv řeči jako například, barbecuing, blanching, braising, coating, deglazing, en croute, en papilote, flambeing, grazing, marinating a poaching, a to jsem teprve na začátku běžně používaných výrazů v angličtině.

Teď si k tomu přičtěte všechny ty francouzské výrazy ve kterých si někteří naši rádoby odborníci stále ještě libují a zjistíte že jenom s češtinou se v našich restauracích asi moc neuplatníte.

Naštěstí je tady teď Hostovka na které se význam těchto výrazů většinou dozvíte.

Mám-li ale být upřímný tak to není řešení protože tím se situace jídelních lístků neřeší a proto mně udivuje, že v Česku, ani na Slovensku není nějaká odborná organizace která by se takovými problémy zabývala.

